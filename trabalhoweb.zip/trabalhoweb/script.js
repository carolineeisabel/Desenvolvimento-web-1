// Adiciona um produto ao carrinho
function adicionarCarrinho(nome, preco) {

    // Recupera o carrinho ou cria um vazio
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

    // Adiciona o produto
    carrinho.push({
        nome: nome,
        preco: preco
    });

    // Salva o carrinho atualizado
    localStorage.setItem("carrinho", JSON.stringify(carrinho));

    // Exibe uma mensagem de confirmação
    alert(nome + " foi adicionado ao carrinho!");
}

// Exibe os produtos do carrinho
function mostrarCarrinho() {

    // Recupera os itens salvos
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

    let lista = document.getElementById("lista-carrinho");
    let total = document.getElementById("total");

    lista.innerHTML = "";
    let soma = 0;

    // Verifica se o carrinho está vazio
    if (carrinho.length === 0) {
        lista.innerHTML = "<p>Seu carrinho está vazio.</p>";
        total.innerHTML = "";
        return;
    }

    // Exibe todos os produtos e calcula o total
    carrinho.forEach((item, index) => {

        soma += item.preco;

        lista.innerHTML += `
            <div class="item-carrinho">
                <h3>${item.nome}</h3>
                <p>Preço: R$ ${item.preco.toFixed(2)}</p>
                <button onclick="removerItem(${index})">Remover</button>
            </div>
        `;
    });

    total.innerHTML = "Total: R$ " + soma.toFixed(2);
}

// Remove um produto do carrinho
function removerItem(index) {

    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

    carrinho.splice(index, 1);

    localStorage.setItem("carrinho", JSON.stringify(carrinho));

    mostrarCarrinho();
}

// Limpa todos os produtos do carrinho
function limparCarrinho() {

    localStorage.removeItem("carrinho");

    mostrarCarrinho();
}

// Finaliza o pedido
function finalizarPedido() {

    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

    if (carrinho.length === 0) {

        alert("Seu carrinho está vazio!");

    } else {

        alert("Pedido finalizado com sucesso!");

        limparCarrinho();
    }
}

// Calcula o valor do bolo personalizado
function calcularValor() {

    let tamanho = Number(document.getElementById("tamanho").value);

    let decoracao = Number(document.getElementById("decoracao").value);

    let valor = tamanho + decoracao;

    // Exibe o valor calculado
    document.getElementById("valorFinal").innerHTML =
        "Valor: R$ " + valor.toFixed(2);

    return valor;
}

// Adiciona o bolo personalizado ao carrinho
function adicionarAoCarrinho() {

    // Obtém as opções escolhidas pelo usuário
    let massa = document.getElementById("massa").value;

    let recheio = document.getElementById("recheio").value;

    let cobertura = document.getElementById("cobertura").value;

    let tamanhoTexto =
        document.getElementById("tamanho").options[
            document.getElementById("tamanho").selectedIndex
        ].text;

    let decoracaoTexto =
        document.getElementById("decoracao").options[
            document.getElementById("decoracao").selectedIndex
        ].text;

    // Calcula o valor do bolo
    let valor = calcularValor();

    // Recupera o carrinho
    let carrinho =
        JSON.parse(localStorage.getItem("carrinho")) || [];

    // Adiciona o bolo personalizado
    carrinho.push({
        nome: "Bolo Personalizado",
        descricao:
            "Massa: " + massa +
            " | Recheio: " + recheio +
            " | Cobertura: " + cobertura +
            " | Decoração: " + decoracaoTexto +
            " | Tamanho: " + tamanhoTexto,
        preco: valor
    });

    // Salva o carrinho
    localStorage.setItem(
        "carrinho",
        JSON.stringify(carrinho)
    );

    // Mensagem de confirmação
    alert("Bolo personalizado adicionado ao carrinho!");
}